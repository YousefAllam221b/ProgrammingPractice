public class assignment{
	public static int mystery(int num , int x ,int y){
		if (num ==0)
			return 0;
		else
			while (num>0){
				y = y + num%10;
				x++;
				num=num/10;
			}
			return y/x;
	}
	public static void main(String[] args){
		System.out.println(mystery(862012,0,0));
	}
}